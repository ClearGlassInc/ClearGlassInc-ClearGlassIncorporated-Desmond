# ClearGlass Shield — SEO, AEO, and content cluster

## Search intent

- Primary: “verifiable privacy VPN” / “auditable VPN architecture” / “business VPN with customer-controlled logs”
- Secondary: WireGuard kill switch, RAM-only VPN servers, no-email VPN account
- Audience: technical operators, privacy-aware professionals, small security-conscious teams
- Differentiating angle: proof artifacts, not streaming or fear marketing

## Titles and metadata

**Home**
- Title: ClearGlass Shield | Privacy you can verify
- H1: Privacy you can verify.
- Meta: ClearGlass Shield is a privacy-first secure connectivity platform with verifiable infrastructure, WireGuard-first routing, and a separate enterprise security plane.

**Proof**
- Title: ClearGlass Proof | Verifiable infrastructure for Shield
- Meta: Server inventory, signed hashes, audit status, and reproducible builds. Privacy as architecture, not slogan.

**Teams**
- Title: ClearGlass Shield Teams | Customer-controlled telemetry
- Meta: Private connectivity for organizations. SSO, device trust, SIEM export, and retention you control.

**Pricing**
- Title: ClearGlass Shield pricing | Private $6, Veil $10, Teams $12
- Meta: Simple ladder. No forced multi-year lock-in.

## Headline options

1. Privacy you can verify.
2. Private by design. Verifiable by default.
3. Encrypted connectivity without surveillance theater.
4. A VPN that publishes its proof.
5. Consumer privacy and enterprise telemetry are not the same product.

## Internal links

- Home → Proof, Pricing, Teams, Privacy
- Proof → Threat model, Claims register, Build sequence
- Teams → Pricing Edge, Privacy (separate-plane section)
- Blog cluster below → Home + Proof

## Content cluster (publish after Phase 1 exists)

| Piece | Intent | CTA |
| --- | --- | --- |
| How ClearGlass Proof works | Category education | Open Proof |
| What “designed not to retain” actually means | Claim hygiene | Read privacy statement |
| Kill switch failure modes we test | Expertise | Join beta |
| Why Teams cannot be a no-history product | Trust / enterprise | Book Teams brief |
| RAM-only gateways and what reboot erases | Technical authority | Architecture |
| Veil: traffic patterns we change, and those we cannot | Honest high-privacy | Veil pricing |
| Payment isolation from tunnel ops | Privacy engineering | Privacy statement |
| Port forwarding without an activity warehouse | Builder audience | Veil plan |

## Schema

SoftwareApplication + Offer list (already on index.html). Add FAQPage only with answers that match CLAIMS.md. Add Organization on parent ClearGlass Inc site, linking Shield as a product.

## Conversion path

Proof page (trust) → Private beta email → Windows client → paid Private → Veil upsell → Teams when SSO is real.

Do not convert from fear. Convert from inspectability.

## Platform-native posts (ethical, durable)

**LinkedIn hook**
Most VPNs ask you to trust a paragraph. Shield ships a proof register that can be empty — and will stay empty until the audit exists.

**X hook**
If your VPN’s trust page cannot show “not audited yet,” it is a brochure.

**Thread spine**
1. Privacy product ≠ anonymity guarantee
2. Separate consumer and enterprise planes
3. Publish hashes before adjectives
4. Veil reduces some signals; say so
5. Link Proof

## Entity coverage

ClearGlass Inc, ClearGlass Shield, ClearGlass Proof, ClearGlass Veil, Shield Teams, Shield Edge, WireGuard, Network Lock, Access ID, Burlington Ontario (company HQ only — not a jurisdiction claim for the network).
