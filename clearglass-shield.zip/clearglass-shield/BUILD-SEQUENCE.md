# ClearGlass Shield — Build Sequence

## Phase 0 — Claims and compliance (weeks 1–3)

Work

- Form product entity; choose operating jurisdiction with specialist counsel
- Draw data-flow diagrams **before** any public no-activity-history policy
- Define memory vs persist vs TTL vs why for every field
- Write threat model, abuse policy, legal-request policy, VDP
- Separate payment, support, auth, and gateway ops
- Freeze claims register

Validation

- Policy-to-system data map complete
- External privacy counsel reviews customer-facing sentences

Exit criteria: no public “designed not to retain…” until the map exists.

## Phase 1 — Private beta (weeks 4–12)

Work

- WireGuard-first control plane
- Windows desktop client, then Android
- Network Lock: kill switch, auto-connect, tunnel DNS, IPv6, simple split tunnel
- Access ID flow; email optional
- 3–5 region gateway footprint
- Status page, privacy policy, initial server inventory
- Automated leak tests: DNS, IPv6, WebRTC, reconnect, kill switch

Validation

- 50–100 controlled beta users
- Zero unresolved critical leak-test failures
- Signed releases

## Phase 2 — Trust and performance (months 4–6)

Work

- Immutable RAM-only gateway images
- Secure boot, image signing, remote attestation, drift control
- Reproducible Windows/macOS client builds
- Launch ClearGlass Proof
- Port forwarding with abuse safeguards
- Multi-hop + experimental Veil
- Independent client, API, infrastructure, and privacy-architecture audit

Validation

- Published audit scope and remediation roadmap
- 100% gateway image integrity checks
- Public release-hash history

## Phase 3 — Teams revenue (months 7–12)

Work

- SSO, MFA, SCIM, RBAC, dedicated egress
- Customer-owned policy and SIEM export
- Terraform provider + management API
- Onboarding package + Shield Security Assessment
- Sell to agencies, consultancies, founder-led distributed teams

Validation

- Repeatable paid onboarding
- Documented support SLAs
- Telemetry retention configurable and customer-controlled

## Immediate next actions (this week)

1. Counsel consult on entity + jurisdiction (Canada vs separate operating company)
2. One-page data inventory: account, payment, support, gateway memory, DNS
3. WireGuard lab: one diskless test node + Windows client smoke test
4. Publish Proof page in “empty / not yet audited” state (already drafted)
5. Do not buy ads or claim feature parity until Phase 1 leak tests pass
