# ClearGlass Shield — Product Bible

**Brand:** ClearGlass Inc.
**Product:** ClearGlass Shield
**Tagline:** Privacy you can verify.
**Status:** Phase 0 specification (2026-09-20)
**Classification:** Internal source of truth + public-safe architecture

This document is the governing product definition. Website copy, claims, engineering, and sales language must not exceed it.

---

## 1. Category and promise

ClearGlass Shield is a **privacy-first secure connectivity platform**, not a Mullvad clone and not a streaming VPN.

Winning combination:

1. Anonymous-style private access (Access ID, email optional)
2. Verifiable infrastructure (ClearGlass Proof)
3. High-performance routing (WireGuard-first, optional Veil/multi-hop)
4. Separate enterprise security plane (Shield Teams) with honest, customer-controlled telemetry

**Core promise**

ClearGlass Shield encrypts the connection, minimizes identity collection, blocks common traffic leaks, and publishes technical proof of how the service operates.

**Defensible public statement (Private mode, only after engineering + audit support it)**

> ClearGlass Shield Private is designed not to retain browsing activity, DNS requests, source IP addresses, destination IP addresses, connection timestamps, session-duration histories, or per-account traffic histories. We publish the controls, exceptions, and audit results behind this commitment.

Do **not** launch with: untraceable, anonymous, zero logs, no logs, better than Mullvad, military-grade, or guaranteed uncorrelation.

---

## 2. Positioning

| Axis | Statement |
| --- | --- |
| Audience | Privacy-conscious individuals, travelers on untrusted networks, technical operators, founder-led teams |
| Enemy | Surveillance-theater VPNs that sell slogans, hide ownership, and ship analytics SDKs |
| Differentiator | Proof before slogans; consumer minimization and enterprise logging as **separate products** |
| Parent brand fit | ClearGlass doctrine: transparency over concealment; trust is a build artifact |
| Non-goals | Streaming unblocking as a headline; dark-web marketing; hidden residential proxy resale |

---

## 3. Feature contract — Shield Private

| Capability | Contract | Notes |
| --- | --- | --- |
| Account | Random ClearGlass Access ID; email optional, never required for basic access | Recovery code generated locally |
| Devices | 7 by default | Count concurrent tunnels, document the rule |
| Price target | USD 6/month or 60/year | No forced multi-year lock-in |
| Protocol | WireGuard-first; OpenVPN / IKEv2 only for compatibility | Prefer userspace where store policy requires it |
| Network Lock | Default-on kill switch, DNS leak protection, IPv6 protection, reconnect guard | Automated leak tests in CI |
| Split tunneling | Per-app and per-domain | Fail closed if rule engine errors |
| Secure DNS | In-tunnel encrypted DNS; no query retention; malware/phishing lists **opt-in** | Blocklists off by default |
| Veil | Optional padding, timing variation, fixed sizing, multi-hop | Never claimed as DAITA-equivalent |
| Routing | Single-hop, multi-hop, region pin, private exit | Publish latency/privacy tradeoff |
| Obfuscation | Restrictive-network / WG obfuscation mode | Label as best-effort |
| Port forwarding | Opt-in, rotating, abuse-safeguarded | Disabled by default |
| Clients | Signed; reproducible desktop builds | No analytics SDKs |
| Servers | RAM-only, immutable image, secure boot, signed updates, remote attestation | Phase 2 |
| Transparency | Live inventory, jurisdiction, provider type, build, audit, incidents | Proof portal |
| Platforms | Win, macOS, Linux, iOS, Android; later extension + router | Windows first |

---

## 4. Architecture principles

1. Gateways run from immutable, signed, memory-resident images. Reboot wipes runtime state.
2. Authentication and payment are logically separate from gateway operations.
3. A gateway must not need persistent browsing, DNS, connection, or traffic-usage records to function.
4. Production change process: signed image → reproducible build → independent verification → staged rollout → automatic rollback.
5. No analytics SDKs, behavioral tracking, ad tech, or session replay in VPN clients.
6. Server inventory distinguishes rented, colocated, dedicated, and customer-operated infrastructure.
7. Private-tier metadata minimization and Teams security logging are separate products and separate policies.

```
Client → Trust Gateway (diskless, attested)
              ├─ Veil (optional shaping / multi-hop)
              ├─ Proof (public inventory, hashes, audits)
              └─ Privacy Exit Network (encrypted DNS, rotating egress)
```

---

## 5. ClearGlass Proof (must ship before bold claims)

Public trust portal contents:

- Server inventory: country, city, provider, ownership model, exit capability
- Live gateway health without user activity
- Signed release hashes for every client and server image
- SBOM for public client releases
- Signing-key fingerprints
- Independent audit reports: scope, severity, remediation, completion date
- Quarterly privacy transparency reports
- Legal-request policy and aggregate statistics
- Security incident disclosure history
- Vulnerability disclosure policy and security contact
- Reproducible-build instructions for desktop clients

**Rule:** unpublished work is marked unpublished. Never display placeholder “passed” audits.

---

## 6. ClearGlass Veil — allowed language

> ClearGlass Veil is designed to reduce some traffic-pattern signals observable by network intermediaries. It cannot guarantee resistance to every traffic-correlation or endpoint-identification technique.

| Mode | Behavior | Tradeoff |
| --- | --- | --- |
| Standard | Encryption + Network Lock | Best speed |
| Private | Rotating exits, stronger DNS isolation | Moderate overhead |
| Veil | Packet-size normalization and selected padding | More bandwidth, lower speed |
| Veil Multi-Hop | Relay + stronger shaping | Highest latency and overhead |

Publish threat model, measured controls, limits, and test methodology. Do not copy competitor feature names or identical protection claims.

---

## 7. ClearGlass Private Exit

Optional premium routes:

- Dedicated static IP for allowlisting
- Private encrypted gateway for home-office or travel
- City/region selection with privacy guidance
- Dual-hop through different jurisdictions
- Private DNS profiles
- Rotating port forwarding
- Residential-network compatibility **only** through lawful, transparent infrastructure partnerships

Forbidden: hidden proxy resale, botnet/residential-IP grey markets.

---

## 8. Shield Teams

Public sentence:

> Private connectivity for organizations, with minimal security telemetry that the customer controls.

Includes: SSO (SAML/OIDC), SCIM, passkeys/TOTP/hardware keys, device trust, private gateways, dedicated egress, per-team DNS/domain policy, SIEM export to customer destinations, customer-defined retention, admin audit trail, API + Terraform, incident-response export bundle.

Enterprise security controls create operational events. Do not describe Teams as a no-activity-history product.

---

## 9. Pricing ladder (targets)

| Plan | Price | Included |
| --- | --- | --- |
| Shield Private | $6/mo or $60/yr | 7 devices, WG, Network Lock, Secure DNS, split tunnel, standard locations |
| Shield Veil | $10/mo or $96/yr | 10 devices, Veil, multi-hop, obfuscation, port forward, priority support |
| Shield Teams | $12/user/mo | SSO, MFA, device trust, DNS policy, SIEM export, managed policies |
| Shield Edge | Custom | Dedicated gateways, private egress, customer keys, deploy support, SLA |

---

## 10. MVP stack

| Layer | Choice |
| --- | --- |
| Tunnel | WireGuard |
| Gateway OS | Hardened minimal Linux, read-only root |
| Hosting (initial) | Dedicated bare metal or carefully selected VMs; migrate to attested immutable fleet |
| Control plane | Go or Rust; PostgreSQL only for required account/subscription state |
| Client | Native Windows first; then platform-native / Flutter |
| Auth | Random Access ID + local recovery code; optional passkeys |
| Payments | Isolated from VPN activity systems; privacy-friendly options |
| DNS | In-tunnel resolver, no query-history retention |
| Observability | Aggregate health and capacity only |
| Deploy | GitHub Actions, signed artifacts, SBOM, scans, staged release |
| Assurance | Code audit, gateway config audit, pentest, public remediation log |

---

## 11. Non-negotiable safeguards

- Do not copy any competitor’s source, copywriting, visual identity, feature brand names, website design, trademarks, or claims.
- Do not say “no logs” until external audits and actual data flows support the full assertion.
- Do not include ad SDKs, hidden telemetry, behavioral analytics, or third-party session replay.
- Do not sell user data, traffic metadata, or aggregated browsing insights.
- Do not promise anonymity or protection from law enforcement, malware, fraud detection, browser tracking, or traffic correlation.
- Keep Private and Teams policies separate.
- Maintain abuse processes that protect network integrity without silently expanding Private-tier retention.

---

## 12. Honest limits (must appear near claims)

A VPN protects communications over untrusted networks and masks the user’s public IP from destination services. It is not a total-anonymity guarantee against fingerprinting, account logins, malware, payment records, or sophisticated traffic correlation.
