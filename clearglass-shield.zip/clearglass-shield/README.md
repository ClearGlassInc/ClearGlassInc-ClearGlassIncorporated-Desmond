# ClearGlass Shield

Privacy-first secure connectivity platform for ClearGlass Inc.

**Tagline:** Privacy you can verify.

This folder is the Phase 0 product system — brand site, claims register, threat model, build sequence, and SEO cluster. It is not a running VPN control plane.

## Site

| File | Purpose |
| --- | --- |
| `index.html` | Public product home |
| `proof.html` | ClearGlass Proof portal (honest pre-launch register) |
| `pricing.html` | Private / Veil / Teams / Edge |
| `teams.html` | Enterprise plane |
| `privacy.html` | Draft Private-mode statement |
| `assets/style.css` | Shared visual system |

Serve locally:

```bash
python3 -m http.server 8080 --directory /home/workdir/artifacts/clearglass-shield
```

## Source of truth

| File | Use |
| --- | --- |
| `PRODUCT.md` | Governing product bible |
| `CLAIMS.md` | What language may ship |
| `THREAT-MODEL.md` | In/out of scope |
| `BUILD-SEQUENCE.md` | Phase 0–3 plan |
| `SEO-CONTENT.md` | Titles, cluster, conversion path |

## Launch rule

Do not advertise “designed not to retain…” or RAM-only production properties until the matching systems and reviews exist. The Proof page is allowed to say **not commissioned** / **empty**.

## Non-goals

- Cloning any third-party VPN’s code, UI, feature names, or claims
- Mixing Teams telemetry language into Private mode
- Streaming-unblock marketing
