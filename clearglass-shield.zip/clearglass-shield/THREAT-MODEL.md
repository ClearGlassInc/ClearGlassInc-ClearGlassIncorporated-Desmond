# ClearGlass Shield — Threat Model (Phase 0)

Scope: consumer Private mode and optional Veil. Teams is a separate model.

## Assets

- User traffic confidentiality and integrity in transit
- User source IP concealment from destination services
- Account unlinkability from real-world identity (best-effort)
- Gateway image integrity
- Client binary integrity
- Payment/identity isolation

## Actors

| Actor | Intent | Shield response |
| --- | --- | --- |
| Local network observer (cafe, hotel, ISP) | Read or inject traffic | Encrypted tunnel + Network Lock |
| Destination service | See home IP | Egress IP substitution |
| Malicious client-side app | Leak outside tunnel | Kill switch, IPv6/DNS/WebRTC tests |
| Curious VPN operator | Browse user activity | Architecture: no activity store; RAM-only; separated planes |
| Compromised gateway | Persist implants, capture packets | Immutable image, attestation, short lifetime, reboot wipes state |
| Network-level pattern analyst | Infer sites from packet sizes/timing | Optional Veil; explicitly incomplete |
| Legal process against company | Compel records | Minimize records; publish process; do not claim immunity |
| Abusive customer | Spam, scanning, crime | Port-forward safeguards, abuse process, documented exceptions |

## In scope

- Encryption of user traffic between client and gateway
- Prevention of common leaks (DNS, IPv6, WebRTC, reconnect race)
- Minimization of retained activity data in Private mode
- Detectable unauthorized gateway drift
- Signed client distribution

## Out of scope (must be disclosed)

- Browser fingerprinting and cookies
- Logging into identifying accounts (Google, bank, work SSO) over the tunnel
- Endpoint malware
- Payment-method identification
- Global passive adversary correlating entry and exit timing at scale
- Protection from lawful process against the user or the company
- Guaranteed connectivity from every censored network

## Trust boundaries

1. User device (untrusted if compromised)
2. Shield client (signed; user-controlled)
3. Control plane (account + entitlement only)
4. Trust Gateway (attested, diskless)
5. Exit network / destination (untrusted)
6. Payment processor (isolated)
7. Support inbox (optional email only)

## Veil honesty clause

Veil changes packet size and timing distributions and can add hops. That raises cost for *some* intermediary observations. It is not a proof against a well-resourced correlator, endpoint identifier, or user who logs into an identifying service.

## Abuse without an activity warehouse

Allowed techniques (must be enumerated in Proof if used):

- Connection-rate limits at the gateway
- Short-lived in-memory counters
- Manual investigation of a reported exit IP + time window supplied by a complainant
- Immediate credential revocation

Disallowed: building a searchable history of destinations “just in case.”
