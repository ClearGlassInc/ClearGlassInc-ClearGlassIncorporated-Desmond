# ClearGlass Shield — Claims Register

**Rule:** If a sentence is not in the ALLOWED column after the listed evidence exists, it does not ship.

Status keys: FORBIDDEN now · CONDITIONAL · ALLOWED after evidence

## Marketing language

| Phrase | Status | Required evidence |
| --- | --- | --- |
| Privacy you can verify | ALLOWED as tagline | Must link to Proof portal; portal must not fake audits |
| Private by design. Verifiable by default. | ALLOWED | Architecture docs published |
| Encrypted connectivity | ALLOWED | WireGuard (or named protocol) in production |
| Untraceable / anonymous / incognito identity | FORBIDDEN | Never |
| Zero logs / no logs / logless | FORBIDDEN until audit | Data-flow map + independent privacy architecture audit + matching ops |
| Designed not to retain [listed activity fields] | CONDITIONAL | Exact field list only; exceptions published |
| Better than Mullvad / DAITA-equivalent | FORBIDDEN | Never compare by name in ads; never clone feature names |
| Military-grade / NSA-proof / FBI-proof | FORBIDDEN | Never |
| Hide from law enforcement | FORBIDDEN | Never |
| Defeats traffic correlation | FORBIDDEN | Veil may reduce *some* signals only |
| No email required for Private | CONDITIONAL | Account flow actually works without email |
| 7 devices | CONDITIONAL | Enforced and documented concurrent-device rule |
| Independently auditable architecture | ALLOWED as intent | Becomes “independently audited” only after a named report exists |
| RAM-only servers | CONDITIONAL | Fleet actually diskless or documented exceptions |
| We do not sell browsing data | ALLOWED once policy + contracts forbid it | Vendor DPAs reviewed |

## Exact Private-mode field list (the only activity-history claim)

When evidence exists, the allowed sentence is:

ClearGlass Shield Private is designed not to retain:

1. browsing activity
2. DNS requests
3. source IP addresses
4. destination IP addresses
5. connection timestamps
6. session-duration histories
7. per-account traffic histories

Any extra field retained (abuse tickets, payment processor IDs, support email if provided) must be listed as an exception on Proof and in the privacy policy.

## Separate-plane rule

| Plane | Allowed telemetry |
| --- | --- |
| Private | Account validity, concurrent device count, payment entitlement, aggregate capacity. No activity history. |
| Teams | Customer-controlled security events: auth, device posture, admin actions, policy hits. Retention set by customer. |
| Proof / status | Gateway health aggregates. No user identifiers. |
| Payments | Isolated processor records. Not joinable to destinations in our systems by design. |

## Abuse and legal process

- Publish a legal-request policy before GA.
- Publish aggregate request counts in quarterly reports.
- Abuse handling may use short-lived, purpose-limited signals that are documented as exceptions. Silent expansion of retention is a product defect.
- DMCA and network-abuse process must not require a Private-tier browsing history store.
