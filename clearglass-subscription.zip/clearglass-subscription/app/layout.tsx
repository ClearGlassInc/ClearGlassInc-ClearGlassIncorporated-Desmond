import "./globals.css"
import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "ClearGlass — See Through Everything.",
  description: "Cybersecurity, AI governance, digital resilience, intelligence, automation, risk engineering.",
  metadataBase: new URL(process.env.APP_BASE_URL || "http://localhost:3000"),
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        {children}
      </body>
    </html>
  )
}
