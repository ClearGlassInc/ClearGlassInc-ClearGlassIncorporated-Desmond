import Header from "@/components/Header"
import Link from "next/link"
import { Suspense } from "react"

export default function SuccessPage({ searchParams }: { searchParams: { session_id?: string } }) {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      <main className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8 py-16">
        <div className="rounded-[20px] border border-zinc-200 bg-white p-8">
          <div className="inline-flex h-8 w-8 items-center justify-center rounded-full bg-emerald-100 text-emerald-700">✓</div>
          <h1 className="mt-4 text-[24px] font-semibold tracking-tight">Payment received — verifying subscription</h1>
          <p className="mt-2 text-[14px] leading-[1.6] text-zinc-600">
            Thank you. Your Stripe Checkout Session {searchParams.session_id ? <span className="font-mono text-[12px] bg-zinc-100 px-1.5 py-0.5 rounded">{searchParams.session_id.slice(0,24)}…</span> : ""} completed.
            <br />Your access is granted only after our webhook verifies the payment with Stripe. This usually takes a few seconds.
          </p>

          <div className="mt-6 rounded-xl bg-zinc-50 border border-zinc-200 p-4 text-[13px] leading-[1.6]">
            <div className="font-medium">What happens next:</div>
            <ol className="mt-2 list-decimal ml-4 space-y-1 text-zinc-700">
              <li>Stripe sends <code>checkout.session.completed</code> to <code>/api/webhook</code></li>
              <li>We verify the Stripe signature with <code>STRIPE_WEBHOOK_SECRET</code></li>
              <li>We record Customer ID, Subscription ID, status, and entitlement</li>
              <li>Dashboard and premium content unlock automatically</li>
            </ol>
            <div className="mt-3 text-[11px] text-zinc-500">If webhook is delayed, refresh in 10–20 seconds. Check Stripe Dashboard → Webhooks → recent events.</div>
          </div>

          <div className="mt-8 flex gap-3">
            <Link href="/dashboard" className="inline-flex h-11 items-center rounded-[10px] bg-[#0a66c2] px-5 text-[14px] font-medium text-white">Go to dashboard</Link>
            <Link href="/account" className="inline-flex h-11 items-center rounded-[10px] border border-zinc-200 px-5 text-[14px] font-medium bg-white">View account</Link>
          </div>

          <div className="mt-8 border-t border-zinc-100 pt-6">
            <div className="text-[12px] font-semibold tracking-wide">VERIFICATION STATUS</div>
            <Suspense fallback={<div className="mt-2 text-[13px] text-zinc-500">Checking…</div>}>
              <StatusChecker />
            </Suspense>
          </div>
        </div>
      </main>
    </div>
  )
}

async function getMe() {
  try {
    const res = await fetch(`${process.env.APP_BASE_URL || ""}/api/me`, { cache: "no-store" })
    return await res.json()
  } catch { return null }
}

// Client component wrapper for polling
function StatusChecker() {
  return (
    <div className="mt-3">
      <ClientPoller />
    </div>
  )
}

// Inline client poller
function ClientPollerWrapper() { return null }

import dynamic from "next/dynamic"
const ClientPoller = dynamic(() => import("./poller"), { ssr: false })
