"use client"
import { useEffect, useState } from "react"

export default function Poller() {
  const [data, setData] = useState<any>(null)
  const [attempt, setAttempt] = useState(0)

  useEffect(() => {
    let timer: any
    const fetchStatus = async () => {
      try {
        const res = await fetch("/api/me")
        const json = await res.json()
        setData(json)
        setAttempt(a => a + 1)
      } catch {}
    }
    fetchStatus()
    timer = setInterval(fetchStatus, 4000)
    return () => clearInterval(timer)
  }, [])

  if (!data) return <div className="text-[13px] text-zinc-500">Checking subscription status…</div>

  if (!data.authenticated) return <div className="rounded-lg bg-amber-50 border border-amber-200 px-3 py-2 text-[13px] text-amber-900">Not signed in — sign in with the same email you used for checkout to link your subscription.</div>

  if (data.isEntitled) {
    return <div className="rounded-lg bg-emerald-50 border border-emerald-200 px-3 py-2 text-[13px] text-emerald-900">✓ Active: {data.entitlementKey} — status {data.status}. Premium access unlocked.</div>
  }

  return (
    <div className="rounded-lg bg-zinc-50 border border-zinc-200 px-3 py-2 text-[13px]">
      <div>Current status: <span className="font-medium">{data.status}</span> {attempt > 1 ? `(checked ${attempt} times)` : ""}</div>
      <div className="mt-1 text-[12px] text-zinc-500">Webhook may still be processing. Wait 10–20s and refresh. If you checked out as guest, sign in with same email.</div>
    </div>
  )
}
