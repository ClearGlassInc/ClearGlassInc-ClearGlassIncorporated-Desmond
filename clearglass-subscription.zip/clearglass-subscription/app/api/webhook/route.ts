import { NextRequest, NextResponse } from "next/server"
import { getStripe } from "@/lib/stripe"
import { getEnv } from "@/lib/env"
import { prisma } from "@/lib/db"
import Stripe from "stripe"

// Important: we need raw body
export const runtime = "nodejs"

async function handleCheckoutCompleted(session: Stripe.Checkout.Session) {
  const stripe = getStripe()
  const customerId = session.customer as string
  const subscriptionId = session.subscription as string
  const planKey = (session.metadata?.planKey || (session as any).subscription_data?.metadata?.planKey) as string
  const entitlementKey = (session.metadata?.entitlementKey) as string
  const internalUserId = session.metadata?.userId

  // Retrieve subscription to get price and period end
  let sub: Stripe.Subscription | null = null
  if (subscriptionId) {
    sub = await stripe.subscriptions.retrieve(subscriptionId)
  }

  // Find user by stripeCustomerId or email
  let user = null
  if (customerId) {
    user = await prisma.user.findFirst({ where: { stripeCustomerId: customerId } })
  }
  if (!user && session.customer_details?.email) {
    user = await prisma.user.findUnique({ where: { email: session.customer_details.email } })
  }
  if (!user && internalUserId && internalUserId !== "guest") {
    user = await prisma.user.findUnique({ where: { id: internalUserId } })
  }

  // If still no user, create minimal user record for mapping if email present (for guest checkout)
  if (!user && session.customer_details?.email) {
    user = await prisma.user.create({
      data: { email: session.customer_details.email, stripeCustomerId: customerId }
    })
  }

  if (!user) {
    console.warn("[webhook] checkout.completed no user mapping", { customerId, email: session.customer_details?.email })
    return
  }

  // Ensure user has stripeCustomerId
  if (!user.stripeCustomerId && customerId) {
    await prisma.user.update({ where: { id: user.id }, data: { stripeCustomerId: customerId } })
  }

  if (sub) {
    const priceId = sub.items.data[0]?.price?.id || ""
    const currentPeriodEnd = new Date(sub.current_period_end * 1000)
    await prisma.subscription.upsert({
      where: { stripeSubscriptionId: sub.id },
      create: {
        userId: user.id,
        stripeCustomerId: customerId,
        stripeSubscriptionId: sub.id,
        stripePriceId: priceId,
        status: sub.status,
        entitlementKey: entitlementKey || (sub.metadata?.entitlementKey) || "signal",
        currentPeriodEnd,
        cancelAtPeriodEnd: sub.cancel_at_period_end,
        lastVerifiedAt: new Date(),
        metadata: { planKey: planKey || sub.metadata?.planKey },
      },
      update: {
        stripePriceId: priceId,
        status: sub.status,
        currentPeriodEnd,
        cancelAtPeriodEnd: sub.cancel_at_period_end,
        lastVerifiedAt: new Date(),
        entitlementKey: entitlementKey || sub.metadata?.entitlementKey || "signal",
      }
    })
    await prisma.auditLog.create({
      data: {
        userId: user.id,
        action: "checkout.session.completed",
        toStatus: sub.status,
        stripeCustomerId: customerId,
        stripeSubscriptionId: sub.id,
        entitlementKey: entitlementKey || "signal",
        metadata: { planKey }
      }
    })
  }
}

async function handleSubscriptionChange(subscription: Stripe.Subscription, eventType: string) {
  const customerId = subscription.customer as string
  const priceId = subscription.items.data[0]?.price?.id || ""
  const currentPeriodEnd = new Date(subscription.current_period_end * 1000)
  const entitlementKey = (subscription.metadata?.entitlementKey) || "signal"

  let user = await prisma.user.findFirst({ where: { stripeCustomerId: customerId } })
  if (!user) {
    // Try to find via email from customer retrieve
    try {
      const stripe = getStripe()
      const customer = await stripe.customers.retrieve(customerId) as Stripe.Customer
      if (customer && !customer.deleted && customer.email) {
        user = await prisma.user.findUnique({ where: { email: customer.email } })
        if (user && !user.stripeCustomerId) {
          await prisma.user.update({ where: { id: user.id }, data: { stripeCustomerId: customerId } })
        }
      }
    } catch {}
  }
  if (!user) {
    console.warn("[webhook] subscription event no user mapping", { customerId, subscriptionId: subscription.id })
    return
  }

  await prisma.subscription.upsert({
    where: { stripeSubscriptionId: subscription.id },
    create: {
      userId: user.id,
      stripeCustomerId: customerId,
      stripeSubscriptionId: subscription.id,
      stripePriceId: priceId,
      status: subscription.status,
      entitlementKey,
      currentPeriodEnd,
      cancelAtPeriodEnd: subscription.cancel_at_period_end,
      trialEnd: subscription.trial_end ? new Date(subscription.trial_end * 1000) : null,
      lastVerifiedAt: new Date(),
      metadata: { eventType }
    },
    update: {
      stripePriceId: priceId,
      status: subscription.status,
      currentPeriodEnd,
      cancelAtPeriodEnd: subscription.cancel_at_period_end,
      trialEnd: subscription.trial_end ? new Date(subscription.trial_end * 1000) : null,
      lastVerifiedAt: new Date(),
      entitlementKey,
    }
  })

  await prisma.auditLog.create({
    data: {
      userId: user.id,
      action: eventType,
      toStatus: subscription.status,
      stripeCustomerId: customerId,
      stripeSubscriptionId: subscription.id,
      entitlementKey,
      metadata: { priceId }
    }
  })
}

export async function POST(req: NextRequest) {
  const env = getEnv()
  const stripe = getStripe()
  const sig = req.headers.get("stripe-signature")
  if (!sig) {
    return NextResponse.json({ error: "Missing signature" }, { status: 400 })
  }

  // Raw body required for verification
  const rawBody = await req.text()

  let event: Stripe.Event
  try {
    event = stripe.webhooks.constructEvent(rawBody, sig, env.STRIPE_WEBHOOK_SECRET)
  } catch (err:any) {
    console.error("[webhook] signature verification failed", err.message)
    return NextResponse.json({ error: "Invalid signature" }, { status: 400 })
  }

  // Idempotency: record event ID
  try {
    const existing = await prisma.processedEvent.findUnique({ where: { stripeEventId: event.id } })
    if (existing) {
      return NextResponse.json({ received: true, duplicate: true })
    }
    await prisma.processedEvent.create({
      data: { stripeEventId: event.id, type: event.type, result: "processing" }
    })
  } catch (e) {
    // If race, treat as duplicate
    console.warn("[webhook] event race", event.id)
  }

  try {
    console.log(`[webhook] ${event.type} ${event.id}`)

    switch (event.type) {
      case "checkout.session.completed": {
        const session = event.data.object as Stripe.Checkout.Session
        await handleCheckoutCompleted(session)
        break
      }
      case "customer.subscription.created":
      case "customer.subscription.updated":
      case "customer.subscription.deleted": {
        const subscription = event.data.object as Stripe.Subscription
        await handleSubscriptionChange(subscription, event.type)
        break
      }
      case "invoice.paid": {
        const invoice = event.data.object as Stripe.Invoice
        if (invoice.subscription) {
          const stripe = getStripe()
          const sub = await stripe.subscriptions.retrieve(invoice.subscription as string)
          await handleSubscriptionChange(sub, "invoice.paid")
        }
        break
      }
      case "invoice.payment_failed": {
        const invoice = event.data.object as Stripe.Invoice
        if (invoice.subscription) {
          const stripe = getStripe()
          const sub = await stripe.subscriptions.retrieve(invoice.subscription as string)
          await handleSubscriptionChange(sub, "invoice.payment_failed")
        }
        break
      }
      case "customer.updated": {
        const customer = event.data.object as Stripe.Customer
        if (customer.email) {
          const existing = await prisma.user.findFirst({ where: { stripeCustomerId: customer.id } })
          if (existing && existing.email !== customer.email) {
            // keep email consistent
            // do not overwrite if conflict
          }
        }
        break
      }
      default:
        console.log(`[webhook] unhandled ${event.type}`)
    }

    await prisma.processedEvent.update({
      where: { stripeEventId: event.id },
      data: { result: "success" }
    })

    return NextResponse.json({ received: true })
  } catch (err:any) {
    console.error("[webhook] handler error", event.type, err.message)
    await prisma.processedEvent.update({
      where: { stripeEventId: event.id },
      data: { result: `error: ${err.message?.slice(0,200)}` }
    }).catch(()=>{})
    // Return 500 so Stripe retries
    return NextResponse.json({ error: "Handler failed" }, { status: 500 })
  }
}
