import { NextRequest, NextResponse } from "next/server"
import { getStripe } from "@/lib/stripe"
import { getEnv } from "@/lib/env"
import { resolvePriceId, PLAN_REGISTRY } from "@/lib/plans"
import { auth } from "@/lib/auth"
import { prisma } from "@/lib/db"
import { checkRateLimit } from "@/lib/rateLimit"
import { z } from "zod"

const bodySchema = z.object({
  planKey: z.string().min(1).max(100),
})

export async function POST(req: NextRequest) {
  try {
    const env = getEnv()
    const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "unknown"
    const rate = checkRateLimit(`checkout:${ip}`, env.CHECKOUT_RATE_LIMIT_PER_MINUTE)
    if (!rate.allowed) {
      return NextResponse.json({ error: "Too many requests. Try again shortly." }, { status: 429, headers: { "Retry-After": "60" } })
    }

    const json = await req.json().catch(() => null)
    const parsed = bodySchema.safeParse(json)
    if (!parsed.success) {
      return NextResponse.json({ error: "Invalid plan selection." }, { status: 400 })
    }
    const { planKey } = parsed.data

    const plan = PLAN_REGISTRY[planKey]
    if (!plan) {
      return NextResponse.json({ error: "Plan not found." }, { status: 404 })
    }

    // Sales-led plans should not create checkout if no price configured
    const priceId = resolvePriceId(planKey, process.env as any)
    if (!priceId) {
      if (plan.availability === "sales-led") {
        return NextResponse.json({ error: "This plan is sales-led. Contact ClearGlass." }, { status: 400 })
      }
      return NextResponse.json({ error: "Plan price not configured. Admin must set env var." }, { status: 500 })
    }

    const session = await auth()
    let userId: string | null = null
    let customerEmail: string | undefined
    let stripeCustomerId: string | undefined

    if (session?.user?.email) {
      const user = await prisma.user.findUnique({ where: { email: session.user.email } })
      if (user) {
        userId = user.id
        stripeCustomerId = user.stripeCustomerId || undefined
        customerEmail = user.email
      }
    }

    const stripe = getStripe()

    // Prevent arbitrary price selection — we use allowlisted priceId only

    const successUrl = `${env.APP_BASE_URL}/success?session_id={CHECKOUT_SESSION_ID}`
    const cancelUrl = `${env.APP_BASE_URL}/cancel`

    const checkoutSession = await stripe.checkout.sessions.create({
      mode: "subscription",
      line_items: [{ price: priceId, quantity: 1 }],
      success_url: successUrl,
      cancel_url: cancelUrl,
      // Use existing customer if we have mapping, else let Stripe create and we map via webhook
      ...(stripeCustomerId ? { customer: stripeCustomerId } : customerEmail ? { customer_email: customerEmail } : {}),
      allow_promotion_codes: true,
      billing_address_collection: "auto",
      tax_id_collection: { enabled: true },
      automatic_tax: { enabled: true },
      metadata: {
        planKey,
        entitlementKey: plan.entitlementKey,
        userId: userId || "guest",
        environment: env.NODE_ENV,
        source: "pricing_page",
      },
      subscription_data: {
        metadata: {
          planKey,
          entitlementKey: plan.entitlementKey,
          userId: userId || "guest",
        }
      }
    })

    return NextResponse.json({ url: checkoutSession.url, sessionId: checkoutSession.id })

  } catch (err:any) {
    console.error("[checkout] error", err?.message)
    // Do not expose raw internal failure details
    return NextResponse.json({ error: "Unable to create checkout session. Please try again." }, { status: 500 })
  }
}
