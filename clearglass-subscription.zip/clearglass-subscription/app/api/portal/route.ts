import { NextRequest, NextResponse } from "next/server"
import { auth } from "@/lib/auth"
import { prisma } from "@/lib/db"
import { getStripe } from "@/lib/stripe"
import { getEnv } from "@/lib/env"

export async function POST(req: NextRequest) {
  try {
    const env = getEnv()
    const session = await auth()
    if (!session?.user?.email) {
      return NextResponse.json({ error: "Not authenticated" }, { status: 401 })
    }
    const user = await prisma.user.findUnique({ where: { email: session.user.email } })
    if (!user?.stripeCustomerId) {
      return NextResponse.json({ error: "No billing account found. Subscribe first." }, { status: 404 })
    }

    const stripe = getStripe()
    const portal = await stripe.billingPortal.sessions.create({
      customer: user.stripeCustomerId,
      return_url: `${env.APP_BASE_URL}/account`,
    })

    return NextResponse.json({ url: portal.url })
  } catch (err:any) {
    console.error("[portal] error", err.message)
    return NextResponse.json({ error: "Unable to open billing portal" }, { status: 500 })
  }
}
