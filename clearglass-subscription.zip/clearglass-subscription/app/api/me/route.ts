import { NextResponse } from "next/server"
import { auth } from "@/lib/auth"
import { prisma } from "@/lib/db"
import { getEntitlement } from "@/lib/entitlement"

export async function GET() {
  const session = await auth()
  if (!session?.user?.email) {
    return NextResponse.json({ authenticated: false, isEntitled: false, status: "none" })
  }
  const user = await prisma.user.findUnique({ where: { email: session.user.email } })
  if (!user) {
    return NextResponse.json({ authenticated: true, isEntitled: false, status: "none" })
  }
  const ent = await getEntitlement(user.id)
  return NextResponse.json({
    authenticated: true,
    email: user.email,
    isEntitled: ent.isEntitled,
    status: ent.status,
    entitlementKey: ent.entitlementKey,
    currentPeriodEnd: ent.currentPeriodEnd,
    cancelAtPeriodEnd: ent.cancelAtPeriodEnd,
    stripeCustomerId: user.stripeCustomerId ? "present" : null,
  })
}
