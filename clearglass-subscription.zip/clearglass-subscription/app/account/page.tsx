import Header from "@/components/Header"
import { auth } from "@/lib/auth"
import { prisma } from "@/lib/db"
import { getEntitlement } from "@/lib/entitlement"
import { redirect } from "next/navigation"
import AccountClient from "./account-client"

export default async function AccountPage() {
  const session = await auth()
  if (!session?.user?.email) redirect("/login?next=/account")
  const user = await prisma.user.findUnique({ where: { email: session.user.email } })
  if (!user) redirect("/login?next=/account")
  const ent = await getEntitlement(user.id)

  return (
    <div className="min-h-screen bg-white">
      <Header />
      <main className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8 py-10">
        <h1 className="text-[24px] font-semibold tracking-tight">Account & billing</h1>
        <p className="mt-2 text-[14px] text-zinc-600">{user.email}</p>

        <div className="mt-8 rounded-[16px] border border-zinc-200 bg-white p-6">
          <div className="flex items-center justify-between">
            <div className="text-[13px] font-medium">Subscription status</div>
            <span className={`rounded-full px-2.5 py-1 text-[11px] font-medium border ${ent.isEntitled ? "bg-emerald-50 border-emerald-200 text-emerald-800" : "bg-zinc-50 border-zinc-200 text-zinc-600"}`}>{ent.status.toUpperCase()}</span>
          </div>
          <div className="mt-4 grid gap-2 text-[13px]">
            <div className="flex justify-between"><span className="text-zinc-500">Entitlement</span><span className="font-medium">{ent.entitlementKey || "—"}</span></div>
            <div className="flex justify-between"><span className="text-zinc-500">Current period end</span><span>{ent.currentPeriodEnd ? ent.currentPeriodEnd.toLocaleDateString() : "—"}</span></div>
            <div className="flex justify-between"><span className="text-zinc-500">Cancel at period end</span><span>{ent.cancelAtPeriodEnd ? "Yes" : "No"}</span></div>
            <div className="flex justify-between"><span className="text-zinc-500">Stripe Customer</span><span className="font-mono text-[11px]">{user.stripeCustomerId ? `${user.stripeCustomerId.slice(0,12)}…` : "none"}</span></div>
          </div>

          <div className="mt-6">
            <AccountClient hasCustomer={Boolean(user.stripeCustomerId)} isEntitled={ent.isEntitled} />
          </div>

          <div className="mt-8 border-t border-zinc-100 pt-6 text-[12px] leading-[1.6] text-zinc-600">
            <div className="font-medium text-zinc-900">Policy</div>
            <ul className="mt-2 list-disc ml-4 space-y-1">
              <li>Active and trialing subscriptions grant access.</li>
              <li>Past due retains access briefly but flagged — configurable to revoke.</li>
              <li>Cancel at period end preserves access until {ent.currentPeriodEnd?.toLocaleDateString() || "period end"}.</li>
              <li>Canceled, unpaid, incomplete_expired lose access.</li>
              <li>All status changes come only from verified Stripe webhooks.</li>
            </ul>
          </div>
        </div>
      </main>
    </div>
  )
}
