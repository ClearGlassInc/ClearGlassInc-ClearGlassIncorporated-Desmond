"use client"
import { useState } from "react"

export default function AccountClient({ hasCustomer, isEntitled }: { hasCustomer: boolean; isEntitled: boolean }) {
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string|null>(null)

  const openPortal = async () => {
    setLoading(true); setError(null)
    try {
      const res = await fetch("/api/portal", { method: "POST" })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || "Portal failed")
      window.location.href = data.url
    } catch (e:any) {
      setError(e.message); setLoading(false)
    }
  }

  if (!hasCustomer) {
    return <div className="rounded-lg bg-zinc-50 border border-zinc-200 px-3 py-2 text-[13px] text-zinc-600">No billing account yet. Subscribe on pricing page to create a Stripe Customer record.</div>
  }

  return (
    <div className="space-y-3">
      {error && <div className="rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-[13px] text-red-800">{error}</div>}
      <button onClick={openPortal} disabled={loading} className="inline-flex h-11 items-center justify-center rounded-[10px] bg-zinc-900 px-5 text-[14px] font-medium text-white disabled:opacity-50">
        {loading ? "Opening portal…" : "Manage billing in Stripe Portal"}
      </button>
      <div className="text-[11px] text-zinc-500">Invoices, payment method, cancel, plan changes via Stripe-hosted portal. Return URL is {typeof window !== "undefined" ? window.location.origin : ""}/account</div>
    </div>
  )
}
