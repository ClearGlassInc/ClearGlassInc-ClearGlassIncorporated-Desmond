import Header from "@/components/Header"

export default function LoginPage({ searchParams }: { searchParams: { verify?: string; next?: string; error?: string } }) {
  const isVerify = Boolean(searchParams.verify)

  return (
    <div className="min-h-screen bg-white">
      <Header />
      <main className="mx-auto max-w-md px-4 sm:px-6 lg:px-8 py-16">
        <div className="rounded-[20px] border border-zinc-200 bg-white p-8">
          {isVerify ? (
            <>
              <h1 className="text-[20px] font-semibold tracking-tight">Check your email</h1>
              <p className="mt-2 text-[14px] leading-[1.6] text-zinc-600">We sent a magic link to your email. Click it to sign in. Link expires in 24 hours and can only be used once. If you use Resend, check inbox; in dev, link is logged to server console.</p>
            </>
          ) : (
            <>
              <h1 className="text-[20px] font-semibold tracking-tight">Sign in to ClearGlass</h1>
              <p className="mt-2 text-[13px] leading-[1.6] text-zinc-600">Passwordless email link — no passwords stored. Your subscription is tied to this email and verified via Stripe webhooks.</p>
              <form action="/api/auth/signin/email" method="POST" className="mt-6 space-y-4">
                <div>
                  <label className="text-[12px] font-medium">Email</label>
                  <input name="email" type="email" required placeholder="you@company.com" className="mt-1 w-full rounded-[10px] border border-zinc-200 px-3 py-2.5 text-[14px] outline-none focus:border-zinc-900" />
                </div>
                <input type="hidden" name="csrfToken" value="" id="csrf" />
                <button type="submit" className="w-full h-11 rounded-[10px] bg-zinc-900 text-white text-[14px] font-medium">Send magic link</button>
                <div className="text-[11px] text-zinc-500">Next: {searchParams.next || "/dashboard"}</div>
              </form>
              {searchParams.error && <div className="mt-4 rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-[13px] text-red-800">{searchParams.error}</div>}
            </>
          )}
        </div>
        <div className="mt-6 text-[11px] text-zinc-500 leading-[1.6]">Security: Auth.js (NextAuth) Email provider, Prisma adapter, JWT session, Resend for delivery. No secrets in client. CSRF protected by Auth.js.</div>
      </main>
    </div>
  )
}
