"use client"
import { useState } from "react"
import PricingCard from "@/components/PricingCard"

type Plan = {
  key: string
  displayName: string
  shortName: string
  description: string
  entitlementKey: string
  interval: "month"|"year"
  features: string[]
  cta: string
  highlighted?: boolean
  availability: "self-serve" | "sales-led" | "coming-soon"
  hasPriceConfigured: boolean
  tier: number
}

export default function PricingClient({ plans }: { plans: Plan[] }) {
  const [loadingKey, setLoadingKey] = useState<string|null>(null)
  const [error, setError] = useState<string|null>(null)

  const handleSelect = async (key: string) => {
    setLoadingKey(key)
    setError(null)
    try {
      const res = await fetch("/api/checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ planKey: key }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || "Checkout failed")
      if (data.url) {
        window.location.href = data.url
      } else {
        throw new Error("No checkout URL returned")
      }
    } catch (e:any) {
      setError(e.message)
      setLoadingKey(null)
    }
  }

  const monthly = plans.filter(p => p.interval === "month")
  const annual = plans.filter(p => p.interval === "year")

  return (
    <div className="space-y-10">
      {error && <div className="rounded-[12px] border border-red-200 bg-red-50 px-4 py-3 text-[13px] text-red-800">{error}</div>}
      <div>
        <h2 className="text-[13px] font-semibold tracking-widest text-zinc-500">MONTHLY</h2>
        <div className="mt-4 grid md:grid-cols-3 gap-6">
          {monthly.map(p => <PricingCard key={p.key} plan={p} onSelect={handleSelect} loadingKey={loadingKey} />)}
        </div>
      </div>
      <div>
        <h2 className="text-[13px] font-semibold tracking-widest text-zinc-500">ANNUAL</h2>
        <div className="mt-4 grid md:grid-cols-3 gap-6">
          {annual.map(p => <PricingCard key={p.key} plan={p} onSelect={handleSelect} loadingKey={loadingKey} />)}
        </div>
      </div>
    </div>
  )
}
