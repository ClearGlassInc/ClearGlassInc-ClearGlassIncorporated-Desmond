import Header from "@/components/Header"
import PricingClient from "./pricing-client"
import { PLAN_REGISTRY } from "@/lib/plans"

export default function PricingPage() {
  // Server component — passes env availability safely (booleans only)
  const envBooleans = {
    STRIPE_PRICE_SIGNAL_MONTHLY: Boolean(process.env.STRIPE_PRICE_SIGNAL_MONTHLY),
    STRIPE_PRICE_SIGNAL_ANNUAL: Boolean(process.env.STRIPE_PRICE_SIGNAL_ANNUAL),
    STRIPE_PRICE_ASSURANCE_MONTHLY: Boolean(process.env.STRIPE_PRICE_ASSURANCE_MONTHLY),
    STRIPE_PRICE_ASSURANCE_ANNUAL: Boolean(process.env.STRIPE_PRICE_ASSURANCE_ANNUAL),
    STRIPE_PRICE_NORTHSTAR_ENTERPRISE: Boolean(process.env.STRIPE_PRICE_NORTHSTAR_ENTERPRISE),
  }

  const clientPlans = Object.values(PLAN_REGISTRY).map(p => ({
    key: p.key,
    displayName: p.displayName,
    shortName: p.shortName,
    description: p.description,
    entitlementKey: p.entitlementKey,
    interval: p.interval,
    features: p.features,
    cta: p.cta,
    highlighted: p.highlighted,
    availability: p.availability,
    hasPriceConfigured: Boolean(process.env[p.priceEnvVar]),
    tier: p.tier,
  }))

  return (
    <div className="min-h-screen bg-white">
      <Header />
      <main className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8 pb-24">
        <section className="pt-12 sm:pt-20 pb-10">
          <div className="max-w-[60ch]">
            <div className="inline-flex rounded-full border border-zinc-200 bg-zinc-50 px-3 py-1 text-[11px] font-medium">Self-serve monthly & annual • Enterprise sales-led</div>
            <h1 className="mt-4 text-[32px] sm:text-[44px] leading-[1.08] tracking-[-0.02em] font-semibold">Choose your level of clarity.</h1>
            <p className="mt-4 text-[16px] leading-[1.6] text-zinc-600">All plans billed via Stripe Checkout. Secure, auditable, cancel anytime via Customer Portal. Tax calculated automatically where configured.</p>
          </div>
        </section>
        <PricingClient plans={clientPlans} />
        <section className="mt-16 grid lg:grid-cols-12 gap-8 border-t border-zinc-100 pt-10">
          <div className="lg:col-span-5">
            <h2 className="text-[14px] font-semibold">Security & privacy notes</h2>
            <p className="mt-2 text-[13px] leading-[1.7] text-zinc-600">We store only: User ID, Stripe Customer ID, Stripe Subscription ID, Stripe Price ID, status, current period end, entitlement key, and last verified time. No card numbers. Webhook signature verified with raw body. Success page does not grant access — entitlement checked server-side from verified events.</p>
          </div>
          <div className="lg:col-span-7 grid sm:grid-cols-2 gap-4 text-[12px]">
            <div className="rounded-xl border border-zinc-200 p-4 bg-white"><div className="font-medium">Checkout</div><div className="text-zinc-600 mt-1">Hosted by Stripe. No raw card forms.</div></div>
            <div className="rounded-xl border border-zinc-200 p-4 bg-white"><div className="font-medium">Portal</div><div className="text-zinc-600 mt-1">Manage billing, invoices, cancellation via Stripe Customer Portal.</div></div>
            <div className="rounded-xl border border-zinc-200 p-4 bg-white"><div className="font-medium">Webhook</div><div className="text-zinc-600 mt-1">Idempotent handling of 7 event types. Duplicate event IDs ignored.</div></div>
            <div className="rounded-xl border border-zinc-200 p-4 bg-white"><div className="font-medium">Access</div><div className="text-zinc-600 mt-1">Server-side entitlement check. No localStorage flags.</div></div>
          </div>
        </section>
      </main>
    </div>
  )
}
