import Header from "@/components/Header"
import Link from "next/link"

export default function CancelPage() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      <main className="mx-auto max-w-2xl px-4 sm:px-6 lg:px-8 py-16">
        <div className="rounded-[20px] border border-zinc-200 bg-white p-8">
          <h1 className="text-[22px] font-semibold tracking-tight">Checkout canceled</h1>
          <p className="mt-2 text-[14px] leading-[1.6] text-zinc-600">Your checkout was canceled. No charge was made. You can return to pricing and try again.</p>
          <div className="mt-6 flex gap-3">
            <Link href="/pricing" className="inline-flex h-11 items-center rounded-[10px] bg-zinc-900 px-5 text-[14px] font-medium text-white">Back to pricing</Link>
            <Link href="/" className="inline-flex h-11 items-center rounded-[10px] border border-zinc-200 px-5 text-[14px] font-medium bg-white">Home</Link>
          </div>
        </div>
      </main>
    </div>
  )
}
