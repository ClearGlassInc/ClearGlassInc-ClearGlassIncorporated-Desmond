import Header from "@/components/Header"
import { auth } from "@/lib/auth"
import { prisma } from "@/lib/db"
import { getEntitlement } from "@/lib/entitlement"
import Link from "next/link"
import { redirect } from "next/navigation"

export default async function DashboardPage() {
  const session = await auth()
  if (!session?.user?.email) {
    redirect("/login?next=/dashboard")
  }
  const user = await prisma.user.findUnique({ where: { email: session.user.email } })
  if (!user) {
    redirect("/login?next=/dashboard")
  }
  const ent = await getEntitlement(user.id)

  if (!ent.isEntitled) {
    return (
      <div className="min-h-screen bg-white">
        <Header />
        <main className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8 py-16">
          <div className="rounded-[20px] border border-amber-200 bg-amber-50 p-8">
            <h1 className="text-[20px] font-semibold">No active subscription</h1>
            <p className="mt-2 text-[14px] text-zinc-700 leading-[1.6]">Your account {session.user.email} does not have an active ClearGlass subscription. Premium dashboard features require an active entitlement verified via Stripe webhooks.</p>
            <div className="mt-6 flex gap-3">
              <Link href="/pricing" className="inline-flex h-11 items-center rounded-[10px] bg-zinc-900 px-5 text-[14px] font-medium text-white">View pricing</Link>
              <Link href="/account" className="inline-flex h-11 items-center rounded-[10px] border border-zinc-200 bg-white px-5 text-[14px] font-medium">Account status</Link>
            </div>
            <div className="mt-6 text-[12px] text-zinc-600">Status: {ent.status} {ent.currentPeriodEnd ? `• renews ${ent.currentPeriodEnd.toLocaleDateString()}` : ""}</div>
          </div>
        </main>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-white">
      <Header />
      <main className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8 py-10">
        <div className="flex items-start justify-between gap-6">
          <div>
            <div className="inline-flex rounded-full bg-emerald-50 border border-emerald-200 px-2.5 py-1 text-[11px] font-medium text-emerald-800">ENTITLED — {ent.entitlementKey?.toUpperCase()} • {ent.status}</div>
            <h1 className="mt-3 text-[28px] font-semibold tracking-tight">ClearGlass Premium Dashboard</h1>
            <p className="mt-2 text-[14px] text-zinc-600 max-w-[60ch]">Verified via Stripe webhook. Entitlement: {ent.entitlementKey}. Period ends {ent.currentPeriodEnd?.toLocaleDateString()} {ent.cancelAtPeriodEnd ? "(cancels at period end)" : ""}</p>
          </div>
          <Link href="/account" className="inline-flex h-9 items-center rounded-[10px] border border-zinc-200 px-4 text-[13px] font-medium bg-white">Manage billing</Link>
        </div>

        <div className="mt-10 grid lg:grid-cols-12 gap-6">
          <div className="lg:col-span-8 space-y-6">
            <div className="rounded-[16px] border border-zinc-200 bg-white p-6">
              <h2 className="text-[14px] font-semibold">Premium intelligence briefings</h2>
              <p className="mt-2 text-[13px] text-zinc-600 leading-[1.6]">This area is server-protected. Only users with status active/trialing/past_due (per policy) can view. Implement your real premium content here — briefings, frameworks, dashboards.</p>
              <div className="mt-4 grid sm:grid-cols-2 gap-3 text-[12px]">
                <div className="rounded-xl border border-zinc-200 p-3 bg-zinc-50">Resilience signal feed — premium</div>
                <div className="rounded-xl border border-zinc-200 p-3 bg-zinc-50">AI governance templates — subscriber only</div>
                <div className="rounded-xl border border-zinc-200 p-3 bg-zinc-50">Dependency mapping workspace — {ent.entitlementKey === "northstar" || ent.entitlementKey === "assurance" ? "available" : "Assurance+ required"}</div>
                <div className="rounded-xl border border-zinc-200 p-3 bg-zinc-50">Evidence provenance log — {ent.entitlementKey === "northstar" ? "available" : "Northstar required"}</div>
              </div>
            </div>
          </div>
          <div className="lg:col-span-4">
            <div className="rounded-[16px] border border-zinc-200 bg-zinc-50 p-5">
              <div className="text-[12px] font-semibold tracking-wide">ACCOUNT</div>
              <div className="mt-3 text-[13px]">{session.user.email}</div>
              <div className="mt-1 text-[12px] text-zinc-500">Entitlement: {ent.entitlementKey} • {ent.status}</div>
              <div className="mt-4 text-[12px] leading-[1.6] text-zinc-600">Manage payment method, invoices, cancellation in Stripe Customer Portal. No card data stored in ClearGlass DB.</div>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}
