import Header from "@/components/Header"
import Link from "next/link"

export default function Home() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      <main className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <section className="pt-16 sm:pt-24 pb-16 border-b border-zinc-100 grid lg:grid-cols-[1.1fr_0.9fr] gap-10 items-start">
          <div>
            <div className="inline-flex items-center gap-2 rounded-full border border-zinc-200 bg-zinc-50 px-3 py-1 text-[11px] font-medium">
              <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" />
              Secure Stripe subscription system — production ready
            </div>
            <h1 className="mt-6 text-[36px] sm:text-[52px] leading-[1.02] tracking-[-0.03em] font-semibold max-w-[18ch]">See Through Everything. Verify Everything.</h1>
            <p className="mt-5 text-[17px] leading-[1.6] text-zinc-600 max-w-[50ch]">ClearGlass builds auditable intelligence, resilience, and AI governance for operators who cannot afford black boxes. Subscribe for premium briefings, assurance workspaces, and organizational reporting.</p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link href="/pricing" className="inline-flex h-11 items-center justify-center rounded-[10px] bg-[#0a66c2] px-6 text-[14px] font-medium text-white">View pricing</Link>
              <Link href="/dashboard" className="inline-flex h-11 items-center justify-center rounded-[10px] border border-zinc-200 bg-white px-6 text-[14px] font-medium">Open dashboard</Link>
            </div>
            <div className="mt-10 grid grid-cols-3 gap-6 border-t border-zinc-100 pt-8 max-w-[520px]">
              <div><div className="text-[11px] tracking-widest font-semibold text-zinc-500">SECURITY</div><div className="mt-1 text-[13px]">Webhook-signed, server-authorized</div></div>
              <div><div className="text-[11px] tracking-widest font-semibold text-zinc-500">COMPLIANCE</div><div className="mt-1 text-[13px]">Stripe Tax + Customer Portal</div></div>
              <div><div className="text-[11px] tracking-widest font-semibold text-zinc-500">RESILIENCE</div><div className="mt-1 text-[13px]">Idempotent event handling</div></div>
            </div>
          </div>
          <div className="rounded-[20px] border border-zinc-200 bg-zinc-50/70 p-5 sm:p-6">
            <div className="text-[12px] font-semibold tracking-wide">SUBSCRIPTION LIFECYCLE — SECURE</div>
            <div className="mt-4 space-y-3 font-mono text-[11px] leading-[1.5]">
              <div className="rounded-xl bg-white border border-zinc-200 p-3">1. Pricing page → client sends plan key only (no Price ID)</div>
              <div className="rounded-xl bg-white border border-zinc-200 p-3">2. Server validates allowlist → creates Stripe Checkout Session (sub mode)</div>
              <div className="rounded-xl bg-white border border-zinc-200 p-3">3. Stripe Checkout (hosted) → payment</div>
              <div className="rounded-xl bg-white border border-zinc-200 p-3">4. Webhook: checkout.session.completed → verify signature → map Customer ID → upsert Subscription</div>
              <div className="rounded-xl bg-white border border-zinc-200 p-3">5. Entitlement check server-side → protected routes</div>
              <div className="rounded-xl bg-white border border-zinc-200 p-3">6. Portal: retrieve Customer ID from DB only → Billing Portal Session</div>
            </div>
            <div className="mt-4 rounded-lg bg-zinc-900 text-zinc-100 p-3 text-[11px]">No secrets in client. No access from success page alone. Webhook is source of truth.</div>
          </div>
        </section>
        <section className="py-12 grid md:grid-cols-3 gap-6">
          {[
            { k: "Signal", d: "Premium briefings, resilience signals, research library." },
            { k: "Assurance", d: "Governance materials, advisory resources, quarterly updates." },
            { k: "Northstar", d: "Evidence workspaces, org reporting, enterprise onboarding." },
          ].map(c => (
            <div key={c.k} className="rounded-[16px] border border-zinc-200 p-5 bg-white">
              <div className="text-[13px] font-semibold">{c.k}</div>
              <div className="mt-1 text-[13px] text-zinc-600">{c.d}</div>
            </div>
          ))}
        </section>
      </main>
      <footer className="border-t border-zinc-200 mt-12 py-8 mx-auto max-w-6xl px-4 sm:px-6 lg:px-8 text-[11px] text-zinc-500">© ClearGlass Inc. — Secure billing via Stripe. No card data stored locally.</footer>
    </div>
  )
}
