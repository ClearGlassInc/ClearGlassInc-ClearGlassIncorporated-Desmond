import NextAuth from "next-auth"
import { PrismaAdapter } from "@auth/prisma-adapter"
import Email from "next-auth/providers/email"
import { prisma } from "./db"
import { Resend } from "resend"
import { getEnv } from "./env"

export const { handlers, auth, signIn, signOut } = NextAuth(() => {
  const env = getEnv()
  const resend = env.RESEND_API_KEY ? new Resend(env.RESEND_API_KEY) : null

  return {
    adapter: PrismaAdapter(prisma),
    trustHost: true,
    providers: [
      Email({
        // If Resend present, use it, otherwise fallback to console log for dev
        async sendVerificationRequest({ identifier, url, provider }) {
          const from = env.EMAIL_FROM
          if (resend) {
            await resend.emails.send({
              from,
              to: identifier,
              subject: "Your ClearGlass sign-in link",
              html: `
                <div style="font-family: ui-sans-serif; max-width: 480px; margin: 0 auto; padding: 24px; border: 1px solid #e4e4e7; border-radius: 16px;">
                  <div style="font-weight: 600; letter-spacing: -0.02em;">ClearGlass Inc.</div>
                  <div style="font-size: 12px; color: #71717a; margin-bottom: 16px;">CLEARGLASS — See Through Everything.</div>
                  <h2 style="font-size: 18px; margin: 0 0 12px;">Sign in to ClearGlass</h2>
                  <p style="font-size: 14px; color: #3f3f46; line-height: 1.6;">Click the button below to sign in. This link expires in 24 hours and can only be used once.</p>
                  <a href="${url}" style="display:inline-block; margin-top: 16px; background:#0a66c2; color:white; padding: 10px 20px; border-radius: 10px; text-decoration:none; font-size:14px; font-weight:500;">Sign in</a>
                  <p style="font-size: 11px; color: #a1a1aa; margin-top: 24px;">If you did not request this, you can safely ignore this email.</p>
                  <p style="font-size: 11px; color: #a1a1aa;">Link: ${url}</p>
                </div>
              `,
            })
          } else {
            console.log(`[DEV] Magic link for ${identifier}: ${url}`)
          }
        },
      }),
    ],
    pages: { signIn: "/login", verifyRequest: "/login?verify=1" },
    session: { strategy: "jwt" },
    callbacks: {
      async session({ session, token }) {
        if (token.sub) {
          (session.user as any).id = token.sub
        }
        return session
      },
    },
  }
})
