import Stripe from "stripe"
import { getEnv } from "./env"

let stripeInstance: Stripe | null = null

export function getStripe(): Stripe {
  if (stripeInstance) return stripeInstance
  const env = getEnv()
  stripeInstance = new Stripe(env.STRIPE_SECRET_KEY, {
    apiVersion: "2024-06-20",
    appInfo: { name: "ClearGlass Subscription", version: "1.0.0" },
    typescript: true,
  })
  return stripeInstance
}
