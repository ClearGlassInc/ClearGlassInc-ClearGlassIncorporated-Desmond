import { z } from "zod"

const envSchema = z.object({
  APP_BASE_URL: z.string().url(),
  DATABASE_URL: z.string().min(1),
  AUTH_SECRET: z.string().min(16),
  AUTH_URL: z.string().url().optional(),
  RESEND_API_KEY: z.string().optional(),
  EMAIL_FROM: z.string().min(1).default("ClearGlass <noreply@clearglass.inc>"),
  STRIPE_SECRET_KEY: z.string().startsWith("sk_"),
  STRIPE_WEBHOOK_SECRET: z.string().startsWith("whsec_"),
  STRIPE_PRICE_SIGNAL_MONTHLY: z.string().startsWith("price_").optional(),
  STRIPE_PRICE_SIGNAL_ANNUAL: z.string().startsWith("price_").optional(),
  STRIPE_PRICE_ASSURANCE_MONTHLY: z.string().startsWith("price_").optional(),
  STRIPE_PRICE_ASSURANCE_ANNUAL: z.string().startsWith("price_").optional(),
  STRIPE_PRICE_NORTHSTAR_ENTERPRISE: z.string().startsWith("price_").optional().or(z.literal("")),
  CHECKOUT_RATE_LIMIT_PER_MINUTE: z.coerce.number().default(10),
  NODE_ENV: z.enum(["development","production","test"]).default("development"),
})

export type Env = z.infer<typeof envSchema>

let cached: Env | null = null

export function getEnv(): Env {
  if (cached) return cached
  // Allow SQLite dev.db fallback parsing: if DATABASE_URL is sqlite file path without protocol, zod still passes min check
  // but prisma expects postgresql. We keep validation lenient for local dev.
  // Actually we validate presence only; for tests we allow file:
  const raw = {
    APP_BASE_URL: process.env.APP_BASE_URL,
    DATABASE_URL: process.env.DATABASE_URL,
    AUTH_SECRET: process.env.AUTH_SECRET,
    AUTH_URL: process.env.AUTH_URL,
    RESEND_API_KEY: process.env.RESEND_API_KEY,
    EMAIL_FROM: process.env.EMAIL_FROM,
    STRIPE_SECRET_KEY: process.env.STRIPE_SECRET_KEY,
    STRIPE_WEBHOOK_SECRET: process.env.STRIPE_WEBHOOK_SECRET,
    STRIPE_PRICE_SIGNAL_MONTHLY: process.env.STRIPE_PRICE_SIGNAL_MONTHLY || undefined,
    STRIPE_PRICE_SIGNAL_ANNUAL: process.env.STRIPE_PRICE_SIGNAL_ANNUAL || undefined,
    STRIPE_PRICE_ASSURANCE_MONTHLY: process.env.STRIPE_PRICE_ASSURANCE_MONTHLY || undefined,
    STRIPE_PRICE_ASSURANCE_ANNUAL: process.env.STRIPE_PRICE_ASSURANCE_ANNUAL || undefined,
    STRIPE_PRICE_NORTHSTAR_ENTERPRISE: process.env.STRIPE_PRICE_NORTHSTAR_ENTERPRISE || undefined,
    CHECKOUT_RATE_LIMIT_PER_MINUTE: process.env.CHECKOUT_RATE_LIMIT_PER_MINUTE,
    NODE_ENV: process.env.NODE_ENV as any,
  }
  const parsed = envSchema.safeParse(raw)
  if (!parsed.success) {
    console.error("❌ Invalid env:", parsed.error.flatten().fieldErrors)
    throw new Error("Invalid environment variables")
  }
  cached = parsed.data
  return cached
}

// Safe for client? No — only server
