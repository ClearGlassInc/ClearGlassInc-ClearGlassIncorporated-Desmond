// Simple in-memory rate limiter — for production use Upstash/Redis if on serverless

type Bucket = { count: number; resetAt: number }
const buckets = new Map<string, Bucket>()

export function checkRateLimit(key: string, limitPerMinute: number): { allowed: boolean; remaining: number; resetAt: number } {
  const now = Date.now()
  const bucket = buckets.get(key)
  if (!bucket || now > bucket.resetAt) {
    const resetAt = now + 60_000
    buckets.set(key, { count: 1, resetAt })
    return { allowed: true, remaining: limitPerMinute - 1, resetAt }
  }
  if (bucket.count >= limitPerMinute) {
    return { allowed: false, remaining: 0, resetAt: bucket.resetAt }
  }
  bucket.count++
  return { allowed: true, remaining: limitPerMinute - bucket.count, resetAt: bucket.resetAt }
}
