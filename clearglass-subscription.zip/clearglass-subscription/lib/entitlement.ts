import { prisma } from "./db"
import type { EntitlementKey } from "./plans"

export type EntitlementStatus = 
  | "active"
  | "trialing"
  | "past_due"
  | "cancel_at_period_end"
  | "canceled"
  | "none"

export type EntitlementResult = {
  isEntitled: boolean
  status: EntitlementStatus
  entitlementKey: EntitlementKey | null
  subscription: any | null
  currentPeriodEnd: Date | null
  cancelAtPeriodEnd: boolean
}

const ENTITLED_STATUSES = new Set(["active","trialing"])

export async function getEntitlement(userId: string): Promise<EntitlementResult> {
  const sub = await prisma.subscription.findFirst({
    where: { userId, status: { in: ["active","trialing","past_due"] } },
    orderBy: { currentPeriodEnd: "desc" },
  })

  if (!sub) {
    return { isEntitled: false, status: "none", entitlementKey: null, subscription: null, currentPeriodEnd: null, cancelAtPeriodEnd: false }
  }

  if (sub.status === "past_due") {
    // Policy: past_due still retains access briefly but flagged — change to false if strict
    return { isEntitled: true, status: "past_due", entitlementKey: sub.entitlementKey as EntitlementKey, subscription: sub, currentPeriodEnd: sub.currentPeriodEnd, cancelAtPeriodEnd: sub.cancelAtPeriodEnd }
  }

  if (sub.cancelAtPeriodEnd && ENTITLED_STATUSES.has(sub.status)) {
    return { isEntitled: true, status: "cancel_at_period_end", entitlementKey: sub.entitlementKey as EntitlementKey, subscription: sub, currentPeriodEnd: sub.currentPeriodEnd, cancelAtPeriodEnd: true }
  }

  if (ENTITLED_STATUSES.has(sub.status)) {
    return { isEntitled: true, status: sub.status as EntitlementStatus, entitlementKey: sub.entitlementKey as EntitlementKey, subscription: sub, currentPeriodEnd: sub.currentPeriodEnd, cancelAtPeriodEnd: sub.cancelAtPeriodEnd }
  }

  return { isEntitled: false, status: sub.status as EntitlementStatus, entitlementKey: sub.entitlementKey as EntitlementKey, subscription: sub, currentPeriodEnd: sub.currentPeriodEnd, cancelAtPeriodEnd: sub.cancelAtPeriodEnd }
}

export function canAccess(required: EntitlementKey | null, actual: EntitlementKey | null): boolean {
  if (!required) return true
  if (!actual) return false
  const order: EntitlementKey[] = ["signal","assurance","northstar"]
  return order.indexOf(actual) >= order.indexOf(required)
}
