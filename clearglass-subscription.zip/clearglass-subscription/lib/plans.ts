/**
 * ClearGlass Plan Registry — server-side source of truth.
 * Client only receives display data, never Price IDs.
 */

export type BillingInterval = "month" | "year"
export type EntitlementKey = "signal" | "assurance" | "northstar"

export type PlanDefinition = {
  key: string // internal registry key, what client sends
  displayName: string
  shortName: string
  description: string
  entitlementKey: EntitlementKey
  interval: BillingInterval
  priceEnvVar: string // env var name holding Stripe Price ID
  features: string[]
  cta: string
  highlighted?: boolean
  availability: "self-serve" | "sales-led" | "coming-soon"
  tier: 1 | 2 | 3
}

export const PLAN_REGISTRY: Record<string, PlanDefinition> = {
  signal_monthly: {
    key: "signal_monthly",
    displayName: "ClearGlass Signal",
    shortName: "Signal",
    description: "For individual professionals and small operators.",
    entitlementKey: "signal",
    interval: "month",
    priceEnvVar: "STRIPE_PRICE_SIGNAL_MONTHLY",
    tier: 1,
    availability: "self-serve",
    cta: "Start with Signal",
    features: [
      "Premium intelligence briefings",
      "Resilience signal updates",
      "Selected frameworks and research",
      "Subscriber resource library",
      "Email support",
    ],
  },
  signal_annual: {
    key: "signal_annual",
    displayName: "ClearGlass Signal — Annual",
    shortName: "Signal Annual",
    description: "Signal with annual billing — 2 months free equivalent.",
    entitlementKey: "signal",
    interval: "year",
    priceEnvVar: "STRIPE_PRICE_SIGNAL_ANNUAL",
    tier: 1,
    availability: "self-serve",
    cta: "Choose Annual",
    features: [
      "Everything in Signal monthly",
      "Annual savings",
      "Priority briefing archive access",
    ],
  },
  assurance_monthly: {
    key: "assurance_monthly",
    displayName: "ClearGlass Assurance",
    shortName: "Assurance",
    description: "For growing companies and advisory clients.",
    entitlementKey: "assurance",
    interval: "month",
    priceEnvVar: "STRIPE_PRICE_ASSURANCE_MONTHLY",
    tier: 2,
    highlighted: true,
    availability: "self-serve",
    cta: "Choose Assurance",
    features: [
      "Everything in Signal",
      "Expanded governance & resilience materials",
      "Priority access to advisory resources",
      "Quarterly risk & dependency updates",
      "Assurance workspace (coming)",
    ],
  },
  assurance_annual: {
    key: "assurance_annual",
    displayName: "ClearGlass Assurance — Annual",
    shortName: "Assurance Annual",
    description: "Assurance with annual billing.",
    entitlementKey: "assurance",
    interval: "year",
    priceEnvVar: "STRIPE_PRICE_ASSURANCE_ANNUAL",
    tier: 2,
    availability: "self-serve",
    cta: "Choose Annual",
    features: [
      "Everything in Assurance monthly",
      "Annual savings",
      "Early access to frameworks",
    ],
  },
  northstar_enterprise: {
    key: "northstar_enterprise",
    displayName: "ClearGlass Northstar",
    shortName: "Northstar",
    description: "For organizations — dependency & evidence workspaces.",
    entitlementKey: "northstar",
    interval: "year",
    priceEnvVar: "STRIPE_PRICE_NORTHSTAR_ENTERPRISE",
    tier: 3,
    availability: "sales-led",
    cta: "Contact ClearGlass",
    features: [
      "Everything in Assurance",
      "Dependency and evidence workspace access",
      "Organizational intelligence reporting",
      "Enterprise onboarding & support",
      "Custom contracts & invoicing",
    ],
  },
}

// Client-safe view — no Price IDs, no env var names
export type ClientPlan = Omit<PlanDefinition, "priceEnvVar"> & { hasPriceConfigured: boolean }

export function getClientPlans(env: Record<string,string|undefined>): ClientPlan[] {
  return Object.values(PLAN_REGISTRY).map(p => {
    const { priceEnvVar, ...rest } = p
    return { ...rest, hasPriceConfigured: Boolean(env[priceEnvVar]) }
  })
}

// Server-side allowlist resolver
export function resolvePriceId(planKey: string, env: Record<string,string|undefined>): string | null {
  const plan = PLAN_REGISTRY[planKey]
  if (!plan) return null
  const priceId = env[plan.priceEnvVar]
  if (!priceId || !priceId.startsWith("price_")) return null
  return priceId
}

export function isEntitledFor(required: EntitlementKey, actual: EntitlementKey | null): boolean {
  if (!actual) return false
  const order: EntitlementKey[] = ["signal","assurance","northstar"]
  return order.indexOf(actual) >= order.indexOf(required)
}
