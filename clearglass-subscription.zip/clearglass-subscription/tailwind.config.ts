import type { Config } from "tailwindcss"
const config: Config = {
  content: ["./app/**/*.{js,ts,jsx,tsx,mdx}", "./components/**/*.{js,ts,jsx,tsx,mdx}"],
  theme: {
    extend: {
      colors: { cg: { accent: "#0a66c2", ink: "#18181b", muted: "#71717a", paper: "#fafafa" } }
    }
  },
  plugins: []
}
export default config
