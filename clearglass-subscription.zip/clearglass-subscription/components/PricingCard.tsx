"use client"
import { useState } from "react"

type Props = {
  plan: {
    key: string
    displayName: string
    shortName: string
    description: string
    entitlementKey: string
    interval: "month"|"year"
    features: string[]
    cta: string
    highlighted?: boolean
    availability: "self-serve" | "sales-led" | "coming-soon"
    hasPriceConfigured: boolean
    tier: number
  }
  onSelect: (key: string)=>void
  loadingKey: string | null
}

export default function PricingCard({ plan, onSelect, loadingKey }: Props) {
  const isLoading = loadingKey === plan.key
  const disabled = !plan.hasPriceConfigured && plan.availability === "self-serve"

  return (
    <div className={`relative flex flex-col rounded-[20px] border p-6 sm:p-7 bg-white ${plan.highlighted ? "border-zinc-900 shadow-[0_0_0_1px_#18181b] scale-[1.02]" : "border-zinc-200"}`}>
      {plan.highlighted && <div className="absolute -top-3 left-6 rounded-full bg-zinc-900 px-2.5 py-1 text-[10px] font-semibold tracking-widest text-white">MOST POPULAR</div>}
      <div className="flex-1">
        <h3 className="text-[18px] font-semibold tracking-tight">{plan.displayName}</h3>
        <p className="mt-1 text-[13px] leading-[1.6] text-zinc-600">{plan.description}</p>
        <div className="mt-5">
          {plan.availability === "sales-led" ? (
            <div className="text-[13px] font-medium text-zinc-900">Sales-led — contact us</div>
          ) : (
            <div className="flex items-baseline gap-2">
              <span className="text-[28px] font-semibold tracking-tight">{disabled ? "—" : (plan.interval === "month" ? "Monthly" : "Annual")}</span>
              <span className="text-[12px] text-zinc-500">/{plan.interval} • Stripe Tax enabled</span>
            </div>
          )}
        </div>
        <ul className="mt-6 space-y-2.5">
          {plan.features.map(f => (
            <li key={f} className="flex gap-2.5 text-[13px] leading-[1.5] text-zinc-700">
              <span className="mt-[2px] inline-flex h-4 w-4 shrink-0 items-center justify-center rounded-full bg-zinc-900 text-[10px] text-white">✓</span>
              <span>{f}</span>
            </li>
          ))}
        </ul>
      </div>
      <div className="mt-8">
        {plan.availability === "sales-led" ? (
          <a href="mailto:hello@clearglass.inc?subject=ClearGlass%20Northstar%20inquiry" className="inline-flex w-full h-11 items-center justify-center rounded-[10px] border border-zinc-200 bg-white px-4 text-[14px] font-medium hover:bg-zinc-50">
            {plan.cta}
          </a>
        ) : (
          <>
            <button
              disabled={disabled || isLoading}
              onClick={() => onSelect(plan.key)}
              className={`inline-flex w-full h-11 items-center justify-center rounded-[10px] px-4 text-[14px] font-medium transition ${disabled ? "bg-zinc-100 text-zinc-400 cursor-not-allowed" : "bg-[#0a66c2] text-white hover:opacity-[0.92] active:opacity-[0.88]"}`}
            >
              {isLoading ? "Redirecting…" : disabled ? "Price not configured" : plan.cta}
            </button>
            {disabled && <p className="mt-2 text-[11px] text-amber-700">Admin: set {plan.key.toUpperCase()} env var in Stripe Dashboard</p>}
          </>
        )}
      </div>
    </div>
  )
}
