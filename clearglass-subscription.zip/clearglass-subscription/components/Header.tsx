import Link from "next/link"

export default function Header() {
  return (
    <header className="sticky top-0 z-40 w-full border-b border-zinc-200 bg-white/80 backdrop-blur">
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8 h-[64px] flex items-center justify-between">
        <Link href="/" className="flex items-center gap-3">
          <div className="h-8 w-8 rounded-[8px] bg-zinc-900 flex items-center justify-center text-white font-semibold text-[13px] tracking-tight">CG</div>
          <div className="leading-tight">
            <div className="text-[13px] font-semibold tracking-tight">ClearGlass Inc.</div>
            <div className="text-[11px] text-zinc-500">CLEARGLASS — See Through Everything.</div>
          </div>
        </Link>
        <nav className="flex items-center gap-1 sm:gap-2">
          <Link href="/pricing" className="px-3 py-2 rounded-full text-[13px] font-medium hover:bg-zinc-100">Pricing</Link>
          <Link href="/dashboard" className="px-3 py-2 rounded-full text-[13px] font-medium hover:bg-zinc-100">Dashboard</Link>
          <Link href="/account" className="px-3 py-2 rounded-full text-[13px] font-medium hover:bg-zinc-100">Account</Link>
          <Link href="/login" className="ml-1 inline-flex h-9 items-center rounded-[10px] bg-zinc-900 px-4 text-[13px] font-medium text-white">Sign in</Link>
        </nav>
      </div>
    </header>
  )
}
