import { describe, it, expect } from "vitest"
import { isEntitledFor } from "../lib/plans"

describe("entitlement hierarchy", () => {
  it("signal < assurance < northstar", () => {
    expect(isEntitledFor("signal", "signal")).toBe(true)
    expect(isEntitledFor("signal", "assurance")).toBe(true)
    expect(isEntitledFor("assurance", "signal")).toBe(false)
    expect(isEntitledFor("northstar", "assurance")).toBe(false)
    expect(isEntitledFor("assurance", "northstar")).toBe(true)
  })
  it("null actual is never entitled", () => {
    expect(isEntitledFor("signal", null)).toBe(false)
  })
})
