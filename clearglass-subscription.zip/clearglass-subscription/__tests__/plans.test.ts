import { describe, it, expect } from "vitest"
import { resolvePriceId, PLAN_REGISTRY } from "../lib/plans"

describe("plan allowlist", () => {
  const env = {
    STRIPE_PRICE_SIGNAL_MONTHLY: "price_sig_mon_123",
    STRIPE_PRICE_ASSURANCE_MONTHLY: "price_ass_mon_456",
  } as any

  it("resolves allowlisted price", () => {
    expect(resolvePriceId("signal_monthly", env)).toBe("price_sig_mon_123")
  })
  it("rejects unknown plan", () => {
    expect(resolvePriceId("hacker_plan", env)).toBeNull()
  })
  it("rejects if env missing", () => {
    expect(resolvePriceId("signal_annual", env)).toBeNull()
  })
  it("registry keys are safe", () => {
    for (const k of Object.keys(PLAN_REGISTRY)) {
      expect(k).toMatch(/^[a-z_]+$/)
    }
  })
})

describe("client cannot inject price", () => {
  it("resolvePriceId ignores client-supplied price", () => {
    const env = { STRIPE_PRICE_SIGNAL_MONTHLY: "price_real" } as any
    // Even if client tries to send price id directly, server only looks up via planKey
    const malicious = "price_evil_injected"
    const result = resolvePriceId(malicious as any, env)
    expect(result).toBeNull()
  })
})
